package spring;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import junit.framework.TestCase;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class JDBCtest extends TestCase {
	public static void main(String[] args) throws SQLException {
		ApplicationContext ap = new ClassPathXmlApplicationContext("application.xml");
		DataSource ds = (DataSource) ap.getBean("dataSource");
		JdbcTemplate jt = (JdbcTemplate) ap.getBean("jdbcTemplate");
		System.out.println(ds.getConnection());
		
		
//		String sql = "update test set name =? where id  = ?";
		String sql = "insert into test values (?,?,?)";
		
		int i = 10;
		List<Object[]> params = new ArrayList<Object[]>();
		params.add(new Object[]{i++,6,7});
		params.add(new Object[]{i++,6,7});
		params.add(new Object[]{i++,6,7});
		params.add(new Object[]{i++,6,7});
		jt.batchUpdate(sql, params);
		
	}
}
