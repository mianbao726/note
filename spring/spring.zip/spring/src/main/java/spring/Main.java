package spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("application.xml");
//		HelloWorld helloWorld = (HelloWorld)applicationContext.getBean("helloWorld");
//		helloWorld.setName("sunny");
//		helloWorld.hello();
//		
//		AnnBean annBean = (AnnBean)applicationContext.getBean("annBean");
//		System.out.println(annBean);
//		
		Cal c = (Cal) applicationContext.getBean("cal");
		System.out.println(c.a());
	}
}
