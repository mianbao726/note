package spring;

import org.springframework.stereotype.Component;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Component("cal")
public class CalImpl implements Cal {

	public int a() {
//		int i = 1/0;
		System.out.println("a  execute... ... ");
		return 99;
	}

}
