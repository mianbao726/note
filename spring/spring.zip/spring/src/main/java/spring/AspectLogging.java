package spring;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Order(9)
@Component
@Aspect
public class AspectLogging {
	
	@Pointcut("execution(public int spring.Cal.*())")
	public void declareJoinPoint(){
		
	}
	
	@Before("spring.AspectLogging.declareJoinPoint()")
	public void before(JoinPoint jp){
		String methodName = jp.getSignature().getName();
		java.util.List<Object> args = Arrays.asList(jp.getArgs());
		System.out.println("before ... ..." + methodName + " args  : " + args);
	}
	
	@After("declareJoinPoint()")
	public void after(JoinPoint jp){
		String methodName = jp.getSignature().getName();
		java.util.List<Object> args = Arrays.asList(jp.getArgs());
		System.out.println("after ... ..." + methodName + " args  : " + args);
	}
	@AfterReturning(value = "declareJoinPoint()" ,returning = "result")
	public void afterReturn(JoinPoint jp , Object result){
		String methodName = jp.getSignature().getName();
		java.util.List<Object> args = Arrays.asList(jp.getArgs());
		System.out.println("@AfterReturning ... ..." + methodName + " args  : " + args + "  result : " + result);
	}
	@AfterThrowing(value = "declareJoinPoint()" , throwing = "ex")
	public void afterThrowing(JoinPoint jp , Exception ex){
		String methodName = jp.getSignature().getName();
		java.util.List<Object> args = Arrays.asList(jp.getArgs());
		System.out.println("@AfterThrowing ... ..." + methodName + " args  : " + args+ "ex is " +ex );
	}
	
	@Around(value = "declareJoinPoint()" )
	public Object around(ProceedingJoinPoint pjp){
		Object ret = null;
		String name = pjp.getSignature().getName();
		try {
			ret = pjp.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("around ... ...");
		return ret;
	}
}
