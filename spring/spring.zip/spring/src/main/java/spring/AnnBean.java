package spring;

import org.springframework.stereotype.Component;

@Component
public class AnnBean {
	private String name;
}
