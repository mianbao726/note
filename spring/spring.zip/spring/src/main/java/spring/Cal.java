package spring;

public interface Cal {
	public int a();
}
