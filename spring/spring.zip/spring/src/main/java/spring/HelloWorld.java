package spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;


@Controller 
public class HelloWorld {

//	@Autowired
//	@Autowired
	@Qualifier("beanName")
	private String name;

	public void hello() {
		System.out.println("hello " + name);
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		System.out.println("set name ... ");
	}

	public HelloWorld() {
		super();
		System.out.println("con  spring ..");
	}
	

}
